DROP TABLE IF EXISTS "Categories";
